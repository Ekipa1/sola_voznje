﻿using UnityEngine;
using System.Collections;

public static class GlobalVariables{
	public static int stVprasanjaCPP; 
	public static bool opravilCPP=false;
	public static int stVprasanjaPP; 
	public static bool opravilPP=false;
}