﻿[System.Serializable]
public class Car {
    public float speed;
	
	}

