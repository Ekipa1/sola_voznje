﻿using UnityEngine;
using System.Collections;

public class button_ena : MonoBehaviour {
    public ScriptableObject scr;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	    if(Input.GetButton("Fire1"))
        {
           
            
        }
	}
}
