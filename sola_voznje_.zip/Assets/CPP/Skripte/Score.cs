﻿[System.Serializable] // to pomeni, da lahko ta razred shranjuj informacije
public class Score {
	/*
	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {

	}*/

	public int stTock;

	public void povecaj(int neki){

		stTock = neki;
	}
	//public bool isTrue;
}
