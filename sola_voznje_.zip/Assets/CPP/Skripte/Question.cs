﻿
[System.Serializable] // to pomeni, da lahko ta razred shranjuj informacije
public class Question {
	/*
	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {

	}*/

	public string question;
	public string odg1;
	public string odg2;
	public string odg3;
	public string pravilniOdg;
	//public bool isTrue;
}
