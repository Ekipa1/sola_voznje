﻿[System.Serializable]
public class Question_ {

    public string vprasanje_;
    public string odgovor1;
    public string odgovor2;
    public string odgovor3;
    public string pravilniodgovor;
}
